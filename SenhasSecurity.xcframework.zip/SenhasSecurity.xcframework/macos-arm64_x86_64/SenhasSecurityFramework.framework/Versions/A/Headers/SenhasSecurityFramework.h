//
//  SenhasSecurityFramework.h
//  SenhasSecurityFramework
//
//  Created by Daffolapmac-184 on 28/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for SenhasSecurityFramework.
FOUNDATION_EXPORT double SenhasSecurityFrameworkVersionNumber;

//! Project version string for SenhasSecurityFramework.
FOUNDATION_EXPORT const unsigned char SenhasSecurityFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SenhasSecurityFramework/PublicHeader.h>

